<?php 

DEFINE("DOCUMENT_ROOT",__DIR__);
DEFINE("BASE_URL_USER",'http://dev.humaneafricamission.org/admin');
DEFINE("BASE_URL_PUBLIC",'http://dev.humaneafricamission.org/public');

?>