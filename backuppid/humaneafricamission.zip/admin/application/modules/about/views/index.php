<!-- page content -->
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper settingPage">
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">About Us </h3>
        </div>
        <div class="box-body">
          <div class="row">
            <div class="col-lg-12">
              <div class="col-md-6 col-md-offset-1 aboutshift">
                <p>This project is build with <a href="http://www.webprojectbuilder.com">Web Project Builder</a>.</p>
                <p><a href="http://www.webprojectbuilder.com">Web Project Builder</a> allows you to generate PHP code of projects using simple user interface without knowledge of programming. This includes CRUD Generator, User Authentication, User Roles, Permission and much more. </p>

                <p>Visit the site to download free php codeigniter scripts and for customization</p>
                <p>URL: <a href="http://www.webprojectbuilder.com">http://www.webprojectbuilder.com</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->