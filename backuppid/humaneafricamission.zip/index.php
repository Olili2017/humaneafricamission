<?php
    header('location: public');
?>